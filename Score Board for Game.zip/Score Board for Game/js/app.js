/*get all the element*/
var scoreA=document.getElementById("scoreA");
var teamAPanlity=document.getElementById("teamASubBtn");
var scoreB=document.getElementById("scoreB");
var playBtn=document.getElementById("play");
var noOfInning=document.getElementById("noOfInning");

var scoreTA=0;
var scoreTB=0;
var winnerScore=10;
var teamAAddBtn=document.getElementById("teamAAddBtn");
teamAAddBtn.addEventListener("click",function(){
	scoreTA++;
	if(scoreTA <=winnerScore){
	scoreA.textContent=scoreTA;
    }else{
    scoreA.classList.add("winner");
    scoreTA=0;
    }
});

teamAPanlity.addEventListener("click",function(){
	scoreTA--;
	scoreA.textContent=scoreTA;
});


teamBAddBtn.addEventListener("click",function(){
	scoreTB++;
	if(scoreTA <=winnerScore){
	scoreB.textContent=scoreTB;
    }else{
    scoreB.classList.add("winner");
    scoreTB=0;
    }
});

teamBPanlity.addEventListener("click",function(){
	scoreTB--;
	scoreB.textContent=scoreTB;
});

noOfInning.addEventListener("change",function(){
  winnerScore=(noOfInning.value)*1;  
});

